FactoryBot.define do
  factory :idea_form do
    category_name {'test'}
    body          {'test'}
  end
end
